from classroom import Classroom
from building import Building


class AcademicBuilding(Building):
    '''
    Class which inherits Building class and represents the educational
    building with its address and the list of audiences.
    Also, it uses class Classroom.
    '''
    def __init__(self, classrooms, address1):
        self.classrooms = classrooms
        super().__init__(address1)

    def total_equipment(self):
        '''
        Returns the list of all equipment which is avaliable in the
        educational building.
        '''
        all_different = []
        all = []
        total = []
        for clas in classrooms:
            for eq in clas.cur_equip:
                all.append(eq)
                if eq not in all_different:
                    all_different.append(eq)
        for equip in all:
            for eq in all_different:
                amount = all.count(equip)
                if equip == eq:
                    total.append((equip, amount))
        total = set(total)
        total = list(total)
        return total

    def __str__(self):
        return self.address


classroom_016 = Classroom('016', 80, ['PC', 'projector', 'mic'])
classroom_007 = Classroom('007', 70, ['PC', 'projector', 'blackboard'])
classroom_008 = Classroom('008', 25, ['PC', 'projector'])
lassrooms = [classroom_016, classroom_007, classroom_008]
academic_building = AcademicBuilding(classrooms, 'Kozelnytska 2a')
