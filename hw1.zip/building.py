class Building:
    '''
    Class Building represents the building by its address.
    '''
    def __init__(self, address1):
        self.address1 = address1


class House(Building):
    '''
    Class House inherits class Building. This class represents
    the building by its address and
    the list of flats.
    '''
    def __init__(self, address1, flats):
        self.flats = flats
        super().__init__(address1)

building = Building('Polubotka')
house = House('Polubotka', ['df', 'dfgb'])
