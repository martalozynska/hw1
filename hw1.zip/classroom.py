class Classroom:

    '''

    This class represents educational audience by its
    number, capacity and equipment.

    '''
    def __init__(self, aud_num, capacity, cur_equip):
        self.aud_num = aud_num
        self.capacity = capacity
        self.cur_equip = cur_equip

    def is_larger(self, comparison):

        '''

        Returns boolean. True only if the first audience
        might contain more students than the second one.

        '''
        if self.capacity > comparison.capacity:
            return True
        return False

    def equipment_differences(self, comparison):
        '''
        Returns the list of equipment from the first
        audience which is absent in the second one.
        '''
        equip_first = []
        for element in self.cur_equip:
            if element not in comparison.cur_equip:
                equip_first.append(element)
        return equip_first

    def __str__(self):
        current_equipment = ''
        for element in self.cur_equip:
            current_equipment += element + ', '
        current_equipment = current_equipment[:-2]
        return 'Classroom {0} has a capacity of {1} persons and has the following equipment: {2}.'.format(self.aud_num, self.capacity, current_equipment)

    def __repr__(self):
        return 'Classroom({0},{1},{2})'.format(self.aud_num, self.capacity, self.cur_equip)

classroom_016 = Classroom('016', 80, ['PC', 'projector', 'mic'])
classroom_007 = Classroom('007', 70, ['PC', 'projector', 'blackboard'])
classroom_008 = Classroom('008', 25, ['PC', 'projector'])
classrooms = [classroom_016, classroom_007, classroom_008]
