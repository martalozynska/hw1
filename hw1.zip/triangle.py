from point import Point


class Triangle:
    '''
    Represents the triangle by its tops. Uses class Point which represents the coordinates of these tops.
    '''
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

    def sides(self):
        '''

        Returns the list of length of triangle's sides.

        '''

        side1 = ((self.a.get_xposition() - self.b.get_xposition())**2 + (self.a.get_yposition() - self.b.get_yposition())**2)**0.5
        side2 = ((self.a.get_xposition() - self.c.get_xposition())**2 + (self.a.get_yposition() - self.c.get_yposition())**2)**0.5
        side3 = ((self.c.get_xposition() - self.b.get_xposition())**2 + (self.c.get_yposition() - self.b.get_yposition())**2)**0.5
        return [side1, side2, side3]

    def is_triangle(self):
        '''

        Returns boolean. True only if such triangle exists.

        '''
        if triangle.sides()[0] + triangle.sides()[1] > triangle.sides()[2] and triangle.sides()[1] + triangle.sides()[2] > triangle.sides()[0] and triangle.sides()[0] + triangle.sides()[2] > triangle.sides()[1]:
            return True
        else:
            return False

    def perimeter(self):
        '''

        Returns the perimeter of the triangle.

        '''
        return sum(triangle.sides())

    def area(self):
        '''

        Returns the area of the triangle.

        '''
    # S = ((p-a)(p-b)(p-c))**1/2
        p = triangle.perimeter() / 2
        S = (p - triangle.sides()[0] * (p - triangle.sides()[1]) * (p - triangle.sides()[2]))**0.5
        return S

triangle = Triangle(Point(1, 1), Point(3, 1), Point(2, 3))

print(triangle.area())
